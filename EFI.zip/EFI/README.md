# RogB460i

ASUS ROG B460i 黑苹果EFI Ventrua 13.2.1

- [Motherboard] ROG STRIX B460-I GAMMING
- [CPU] Intel Core i5-10400
- [GPU] Intel UHD630 (no dGPU)
- [WiFi] BCM943602CS + PCIE转接卡

已定制USB，通过PCIE转接板使用白苹果网卡，蓝牙供电插在USB2.0接口通讯。因USB端口数量显示，主板的蓝牙USB通道已关闭。

重要⚠️‼️从Release目录下载EFI后请自行更改三码之后再登陆自己的ID

![Image](https://user-images.githubusercontent.com/16497611/234818112-6f7c703d-bd6d-4a74-bc74-bcac5f311fc9.png)


![Image](https://user-images.githubusercontent.com/16497611/234818176-b1bff158-06ad-4bb0-814b-b7b43c89fcb8.png)
